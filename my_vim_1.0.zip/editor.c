#include "editor.h"
#include "render.h"
#include "clipboard.h"
#include "commands.h"
#include <ncurses.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <wctype.h>
#include <wchar.h>
#define CTRL(x) ((x) & 0x1F)
#define CTRL_J 128 // 新的常量值


#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif
#include <stdbool.h>

// 全局变量
Mode current_mode = NORMAL_MODE; // 初始为 Normal 模式
// 全局变量
char editor_filename[256] = {'\0'}; // 编辑器文件名
wchar_t text_buffer[1024][1024] = {{'\0'}}; // 支持多行文本
char command_buffer[1024] = {'\0'};      // 命令输入缓冲
int cursor_x = 0, cursor_y = 0, max_lines = 0;

// 获取当前模式
Mode get_mode() {
    return current_mode;
}

// 设置模式
void set_mode(Mode mode) {
    current_mode = mode;
}

// 全局变量
char history_buffer[HISTORY_SIZE][1024][1024] = {{{'\0'}}}; // 撤销历史记录栈
int history_index = 0; // 当前历史记录的索引

// 保存当前状态到历史记录
void save_to_history() {
    if (history_index < HISTORY_SIZE - 1) {
        memcpy(history_buffer[history_index + 1], text_buffer, sizeof(text_buffer));
        history_index++;
    } else {
        // 可选：处理历史记录已满的情况
    }
}

// 撤销操作
void undo() {
    if (history_index > 0) {
        memcpy(text_buffer, history_buffer[history_index - 1], sizeof(text_buffer));
        history_index--;
        render_screen(); // 重新渲染屏幕
    }
}

// normal_mode 模式
void handle_normal_mode() {
    curs_set(1); // 显示光标
    int ch = wgetch(editor_win);

    switch (ch) {
        case 'i': // 切换到 Insert 模式
            set_mode(INSERT_MODE);
            break;
        case 'u': // 撤销操作
            undo();
            break;
        case ':': // 切换到 Command 模式
            set_mode(COMMAND_MODE);
            memset(command_buffer, 0, sizeof(command_buffer)); // 清空命令缓冲区
            break;
        case 'h': // 左移光标
            if (cursor_x > 0) {
                cursor_x--; // 向左移动光标
            }
            break;
        case 'l': // 右移光标
            if (cursor_x < wcslen(text_buffer[cursor_y])) {
                cursor_x++; // 向右移动光标
            }
            break;
        case 'j': // 下移光标
            if (cursor_y < max_lines - 1) {
                cursor_y++;
                // 确保光标不越过当前行的最大长度
                cursor_x = my_min(cursor_x, wcslen(text_buffer[cursor_y]));
            }
            break;
        case 'k': // 上移光标
            if (cursor_y > 0) {
                cursor_y--;
                // 确保光标不越过当前行的最大长度
                cursor_x = my_min(cursor_x, wcslen(text_buffer[cursor_y]));
            }
            break;
        case 'y': // 复制当前行到剪贴板
            copy_to_clipboard(text_buffer[cursor_y]);
            break;
        case 'd': // 剪切当前行到剪贴板
            cut_to_clipboard(cursor_y);
            break;
        case 'p': // 粘贴剪贴板内容
            if (get_clipboard_count() > 0) {
                const wchar_t *clipboard_text = get_clipboard_entry(get_clipboard_count() - 1);
                paste_from_clipboard(clipboard_text);
            }
            break;
    }

    // 更新屏幕显示
    render_screen();
}


// 打开文件
void open_file(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error opening file");
        return;
    }

    // 清空缓冲区
    memset(text_buffer, 0, sizeof(text_buffer));

    // 逐行读取文件内容
    int i = 0;
    while (fgetws(text_buffer[i], MAX_LINE_LENGTH, file) != NULL) {
        // 移除行尾的换行符
        text_buffer[i][wcslen(text_buffer[i]) - 1] = '\0';

        i++;
        if (i >= MAX_LINES) {
            fprintf(stderr, "Error: File exceeds maximum line count (%d)\n", MAX_LINES);
            break;
        }
    }

    max_lines = i; // 实际行数
    fclose(file);

    // 保存文件名
    strncpy(editor_filename, filename, sizeof(editor_filename) - 1);
    editor_filename[sizeof(editor_filename) - 1] = '\0';

    // 将光标移动到文本末尾
    cursor_y = max_lines - 1;
    cursor_x = wcslen(text_buffer[cursor_y]);

    // 重新渲染屏幕
    render_screen();
}

// 保存文件
void save_file(const char *filename) {
         if (filename == NULL || strcspn(filename, "\n") == 0) {
        mvprintw(LINES - 1, 0, "Error: No filename provided");
        refresh();
        return;
    }

    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        mvprintw(LINES - 1, 0, "Error: Could not open file %s for writing", filename);
        refresh();
        return;
    }

    // 写入编辑器内容
    for (int i = 0; i < max_lines; i++) {
        fputws(text_buffer[i], file);
        fputws(L"\n", file);

    fclose(file);

    // 提示保存成功
    mvprintw(LINES - 1, 0, "File %s saved successfully", filename);
    refresh();
    }
}
// 处理 wq 命令
void handle_wq_command() {
    save_file(editor_filename);
    cleanup_editor();
    exit(0);
}

// 插入字符模式
void insert_char(wchar_t ch) {
    // 当前行未满，可以直接插入字符
    if (cursor_x < MAX_LINE_LENGTH - 1) {
        size_t line_length = wcslen(text_buffer[cursor_y]);

        if (line_length < MAX_LINE_LENGTH - 1) {
            // 将光标后的字符右移，为新字符腾出空间
            wmemmove(&text_buffer[cursor_y][cursor_x + 1], &text_buffer[cursor_y][cursor_x], line_length - cursor_x);

            // 插入新字符
            text_buffer[cursor_y][cursor_x] = ch;
            cursor_x++;
        }
    } 
    // 当前行已满，需要将溢出的部分移到下一行
    else if (cursor_y + 1 < MAX_LINES) {
        size_t line_length = wcslen(text_buffer[cursor_y]);

        // 如果是新行，则增加总行数
        if (cursor_y + 1 == max_lines) {
            max_lines++;
        }

        // 将光标位置后的字符移到下一行的开头
        wmemmove(text_buffer[cursor_y + 1], &text_buffer[cursor_y][cursor_x], line_length - cursor_x + 1);

        // 插入新字符
        text_buffer[cursor_y][cursor_x] = ch;

        // 截断当前行
        text_buffer[cursor_y][cursor_x + 1] = L'\0';

        // 光标移动到下一行的行首
        cursor_x = 0;
        cursor_y++;
    } 
    // 行数达到限制，无法插入更多字符
    else {
        fprintf(stderr, "Error: Maximum line count exceeded\n");
    }
        render_screen();
}

// 插入模式保持函数
void handle_insert_mode() {
    int ch = wgetch(editor_win);

    switch (ch) {
        case 27: // ESC 切换到 Normal 模式
            set_mode(NORMAL_MODE);
            break;

        case KEY_BACKSPACE: // 兼容系统的退格键
        case 127:
            if (cursor_x > 0) {
                cursor_x--;
                text_buffer[cursor_y][cursor_x] = L'\0';
            } else if (cursor_y > 0) {
                cursor_x = wcslen(text_buffer[cursor_y - 1]);
                wcscat(text_buffer[cursor_y - 1], text_buffer[cursor_y]);
                for (int i = cursor_y; i < max_lines - 1; i++) {
                    wcscpy(text_buffer[i], text_buffer[i + 1]);
                }
                max_lines--;
                cursor_y--;
            }
            break;

        case KEY_LEFT: // 左箭头
            if (cursor_x > 0) {
                cursor_x--;
            }
            break;

        case KEY_RIGHT: // 右箭头
            if (cursor_x < wcslen(text_buffer[cursor_y])) {
                cursor_x++;
            }
            break;

        case KEY_DOWN: // 下箭头
            if (cursor_y < max_lines - 1) {
                cursor_y++;
                cursor_x = my_min(cursor_x, wcslen(text_buffer[cursor_y])); // 确保光标在行内
            }
            break;

        case KEY_UP: // 上箭头
            if (cursor_y > 0) {
                cursor_y--;
                cursor_x = my_min(cursor_x, wcslen(text_buffer[cursor_y])); // 确保光标在行内
            }
            break;

        case '\n': // 回车换行
            for (int i = max_lines; i > cursor_y; i--) {
                wcscpy(text_buffer[i + 1], text_buffer[i]);
            }
            max_lines++;
            wcscpy(text_buffer[cursor_y + 1], &text_buffer[cursor_y][cursor_x]);
            text_buffer[cursor_y][cursor_x] = L'\0';
            cursor_x = 0;
            cursor_y++;
            break;

        default: // 普通字符输入
            if (iswprint(ch)) { // 确保是可打印字符
                insert_char((wchar_t)ch);
            }
            break;
    }

    render_screen(); // 每次输入后刷新屏幕
}

// 清理编辑器
void cleanup_editor() {
    delwin(editor_win); // 删除编辑器窗口
    delwin(status_win); // 删除状态窗口
    delwin(cmd_win); // 删除命令窗口
    endwin(); // 结束 ncurses 模式，恢复终端设置
    exit(0); // 安全退出程序
}
