#ifndef RENDER_H
#define RENDER_H

#include "editor.h"

// 初始化编辑器
void init_editor();

// 渲染屏幕
void render_screen();
int my_max(int a, int b);
int my_min(int a, int b);
#endif // RENDER_H
