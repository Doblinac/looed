#ifndef EDITOR_H
#define EDITOR_H

#include <ncurses.h>

#define MAX_LINE_LENGTH 1024
#define MAX_LINES 1024
#define HISTORY_SIZE 100 // 添加撤销历史记录的最大长度

typedef enum { NORMAL_MODE, INSERT_MODE, COMMAND_MODE } Mode;

extern Mode current_mode;
extern char editor_filename[256];
extern wchar_t text_buffer[MAX_LINES][MAX_LINE_LENGTH];
extern char command_buffer[1024];
extern int cursor_x, cursor_y, max_lines;
extern char history_buffer[HISTORY_SIZE][MAX_LINES][MAX_LINE_LENGTH]; // 添加撤销历史记录栈
extern int history_index;

extern WINDOW *editor_win, *status_win, *cmd_win;

// 函数声明
Mode get_mode();
void set_mode(Mode mode);
void handle_normal_mode();
void handle_insert_mode();
void cleanup_editor();
void undo();
void open_file(const char *filename);
void save_file(const char *filename);
void handle_wq_command();
void insert_char(wchar_t ch);

#endif // EDITOR_H
