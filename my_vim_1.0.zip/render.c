#include "editor.h"
#include "render.h"
#include "clipboard.h"
#include "commands.h"
#include <ncurses.h>
#include <string.h>
#include <stdlib.h>

// 定义 max 和 min 函数
int my_max(int a, int b) {
    return (a > b) ? a : b;
}

int my_min(int a, int b) {
    return (a < b) ? a : b;
}

// 全局变量设置
WINDOW *editor_win, *status_win, *cmd_win;

// 光标相对窗口的偏移量
int offset_y = 0;

// 初始化编辑器
void init_editor() {
    int height, width;
    getmaxyx(stdscr, height, width);

    // 窗口分配
    editor_win = newwin(height - 3, width, 1, 0);
    status_win = newwin(1, width, height - 2, 0);
    cmd_win = newwin(1, width, height - 1, 0);
}

// 渲染屏幕
void render_screen() {
    int height, width;
    getmaxyx(stdscr, height, width); // 获取当前终端尺寸

    // 编辑区渲染
    werase(editor_win);
    box(editor_win, 0, 0);

    // 确保光标始终在窗口中间偏下的可见区域
    int visible_lines = height - 4; // 可见行数
    if (cursor_y < offset_y) {
        offset_y = cursor_y; // 如果光标在当前显示区域上方，调整偏移量
    } else if (cursor_y >= offset_y + visible_lines) {
        offset_y = cursor_y - visible_lines + 1; // 如果光标在当前显示区域下方，调整偏移量
    }

    // 计算需要显示的行数
    int start_line = my_max(0, offset_y);
    int end_line = my_min(max_lines, start_line + visible_lines);

    for (int i = start_line; i <= end_line; i++) {
        if (i >= 0 && i < max_lines) {
            char mb_str[MAX_LINE_LENGTH * 4]; // 足够大的缓冲区来存储转换后的多字节字符串
            size_t len = wcstombs(mb_str, text_buffer[i], sizeof(mb_str));
            if (len != (size_t)-1) {
                mvwprintw(editor_win, i - start_line + 1, 1, "%s", mb_str);
            }
        }
    }

    // 刷新编辑区以显示光标
    int cursor_win_y = cursor_y - offset_y + 1; // 计算光标在窗口中的位置
    wmove(editor_win, cursor_win_y, cursor_x + 1); // 将光标移动到窗口中的正确位置
    wrefresh(editor_win);

    // 状态栏渲染
// 状态栏显示剪贴板信息
      werase(status_win);
      if (current_mode == NORMAL_MODE) {
          if (get_clipboard_count() > 0) {
              const wchar_t *clipboard_text = get_clipboard_entry(get_clipboard_count() - 1);
             mvwprintw(status_win, 0, 0, "[NORMAL MODE] Clipboard: %ls", clipboard_text);
                   } else {
            mvwprintw(status_win, 0, 0, "[NORMAL MODE] Clipboard is empty");
                   }
       } else if (current_mode == INSERT_MODE) {
            mvwprintw(status_win, 0, 0, "[INSERT MODE] Press ESC to return to normal mode");
       } else if (current_mode == COMMAND_MODE) {
            mvwprintw(status_win, 0, 0, "[COMMAND MODE] Type your command");
    }
    wrefresh(status_win);

    // 命令行
    werase(cmd_win);
    if (current_mode == COMMAND_MODE) {
        mvwprintw(cmd_win, 0, 0, ":%s", command_buffer);
        wmove(cmd_win, 0, strlen(":") + strlen(command_buffer)); // 移动光标到命令模式下的位置
    }
    wrefresh(cmd_win);

    // 确保光标在正确位置
    if (current_mode == NORMAL_MODE || current_mode == INSERT_MODE) {
        wmove(editor_win, cursor_win_y, cursor_x + 1); // 光标在文本编辑区
        curs_set(1); // 显示光标
    } else if (current_mode == COMMAND_MODE) {
        wmove(cmd_win, 0, strlen(":") + strlen(command_buffer)); // 光标在命令行
        curs_set(1); // 显示光标
    }
}
